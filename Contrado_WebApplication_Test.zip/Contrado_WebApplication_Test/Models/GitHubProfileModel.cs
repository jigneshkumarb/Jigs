﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BusinessLayer;

namespace Contrado_GitHub.Models
{
    public class GitHubProfileModel
    {
        public GitHubProfileModel()
        {
            this.GitHubRepositories = new List<GitHubRepository>();
        }

        [Required]
        public string UserName { get; set; }
        public string Location { get; set; }
        public string AvatarUrl { get; set; }

        public IList<GitHubRepository> GitHubRepositories { get; set; }
    }
}