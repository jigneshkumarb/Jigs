﻿using Interfaces;
using System.Configuration;

namespace BusinessLayer.Configurations
{
    public class Config : IConfig
    {
        public string GitHubUrl => string.IsNullOrEmpty(ConfigurationManager.AppSettings["EndPointURL"])
            ? string.Empty
            : ConfigurationManager.AppSettings["EndPointURL"];

        public int NumberOfReposToShow => string.IsNullOrEmpty(ConfigurationManager.AppSettings["gitHub.NumberOfReposToShow"])
            ? 0
            : int.Parse(ConfigurationManager.AppSettings["gitHub.NumberOfReposToShow"]);
    }
}
