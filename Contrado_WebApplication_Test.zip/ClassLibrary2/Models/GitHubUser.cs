﻿using System.Collections.Generic;
using Newtonsoft.Json;
using BusinessLayer;

namespace BusinessLayer
{
    public class GitHubUser : UserDetail
    {
        [JsonProperty("repos_url")]
        public string RepositoriesUrl { get; set; }
        [JsonIgnore]
        public IList<GitHubRepository> GitHubRepositories { get; set; }
    }
}
