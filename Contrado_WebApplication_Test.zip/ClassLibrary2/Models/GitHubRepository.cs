﻿using System;
using Newtonsoft.Json;


namespace BusinessLayer
{
    public class GitHubRepository
    {
        [JsonProperty("name")]
        public string RepositoryName { get; set; }
        [JsonProperty("html_url")]
        public string RepositoryUrl { get; set; }
        [JsonProperty("stargazers_count")]
        public int StarCount { get; set; }
    }
}
