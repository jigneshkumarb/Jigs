﻿using Interfaces;
using Newtonsoft.Json;

namespace BusinessLayer.Common
{
    public class JsonConverter : IConverter
    {

        public T DeserializeObject<T>(string input)
        {
            return JsonConvert.DeserializeObject<T>(input);
        }
    }
}
