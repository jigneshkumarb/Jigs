﻿namespace Interfaces
{
    public interface IWebClient
    {
        string DownloadString(string url);
    }
}
