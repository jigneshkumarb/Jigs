﻿namespace Interfaces
{
    public interface IConverter
    {
        T DeserializeObject<T>(string input);
    }
}
