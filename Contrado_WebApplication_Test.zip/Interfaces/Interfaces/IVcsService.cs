﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Interfaces
{
    public interface IVcsService<out TUser, TRepository>
    {
        TUser GetUser(string userName);
        IList<TRepository> GetRepositories(string url);
    }
}
