﻿using System.Security.Cryptography.X509Certificates;

namespace Interfaces
{
    public interface IConfig
    {
        string GitHubUrl { get; }

        int NumberOfReposToShow { get; }
    }
}
